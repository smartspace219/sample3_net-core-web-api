using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using System.Text.RegularExpressions;
using Npgsql;
namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class LogApiController : ControllerBase
    {
        private const string CONNECTION_STRING = "Host=localhost;Port=5432; Username=postgres; Password=123; Database=sample";
        private readonly ILogger<LogApiController> _logger;

        public LogApiController(ILogger<LogApiController> logger)
        {
            _logger = logger;
        }

        [HttpPost("LogData")]
        public async Task PostLogData([FromBody] object receive)
        {
            try
            {
                Console.WriteLine("body:" + receive);
                await using var connection = new NpgsqlConnection(CONNECTION_STRING);
                await connection.OpenAsync();
                //data = "{\"serial\": \"F812\"}\r\n1710166717 ebus INFO ebs;start;None;None\r\n1710166717 ebus INFO mqt;init;('localhost', 1883);ebus\r\n1710166717 ebus INFO dtt;init;('ebus', False, 'ebus.yaml');treehandler_mqtt\r\n1710166717 ebus INFO dtt;init;treehandler;None\r\n1710166717 config INFO cfg;start;None;None\r\n1710166717 config INFO dtt;init;treehandler;None\r\n1710166717 config INFO cfg;git;dir_exists;init_repo\r\n1710166717 ebus INFO ebs;load_hex;get_hex_file;ep-rog-2022.hex\r\n1710166718 ebus INFO mqt;start_loop;None;None\r\n1710166718 ebus INFO mqt;connected;None;None\r\n1710166719 config INFO cfg;load;yaml;loaded_yaml\r\n1710166719 config INFO mqt;init;('localhost', 1883);config\r\n1710166719 config INFO dtt;init;('config', False, None);treehandler_mqtt\r\n1710166719 config INFO cfg;load;json;file_load\r\n1710166720 ebus ERROR dtt;request_item;config;timeout\r\n1710166722 ebus ERROR dtt;request_item;system;timeout\r\n1710166723 config INFO mqt;start_loop;None;None\r\n1710166723 config INFO mqt;connected;None;None\r\n1710166724 aio INFO und;start;None;None\r\n1710166724 aio INFO dio;init;init;Dummy Mode: False\r\n";
                String[] logLines = Regex.Split(receive + "", "\r\n|\r|\n");
                jsonData json = JsonSerializer.Deserialize<jsonData>(logLines[0]);
                Console.WriteLine("cc:" + logLines.Length);
                Console.WriteLine("serial:" + json.serial);
                string serial = json.serial;
                if (serial.Length > 4) serial = serial.Substring(0, 4);

                for (int i = 1; i < logLines.Length; i++)
                {
                    string line = logLines[i];
                    if (line != "")
                    {
                        string[] values = line.Split(new char[] { ' ', ';' });
                        string created = localtime(long.Parse(values[0]));
                        string component = values[1];
                        string ev = values[2];
                        string short_1 = values[3];
                        string short_2 = values[4];
                        string information = values[5];
                        if (component.Length > 3) component = component.Substring(0, 3);
                        if (ev.Length > 3) ev = ev.Substring(0, 4);
                        if (short_1.Length > 10) short_1 = short_1.Substring(0, 10);
                        if (short_2.Length > 10) short_2 = short_2.Substring(0, 10);
                        await using var cmd = new NpgsqlCommand("INSERT INTO log_data (serial, created, component, event, short_1, short_2, information) VALUES (@serial, @created, @component, @event, @short_1, @short_2, @information)", connection);

                        cmd.Parameters.AddWithValue("serial", serial);
                        cmd.Parameters.AddWithValue("created", DateTime.Parse(created).ToUniversalTime());
                        cmd.Parameters.AddWithValue("component", component);
                        cmd.Parameters.AddWithValue("event", ev);
                        cmd.Parameters.AddWithValue("short_1", short_1);
                        cmd.Parameters.AddWithValue("short_2", short_2);
                        cmd.Parameters.AddWithValue("information", information);
                        await cmd.ExecuteNonQueryAsync();
                    }
                    
                }
            }
            catch (Exception ex){
                Console.WriteLine(ex.ToString());
            }
        }
        public static string localtime(long unixTime)
        {
            // Convert Unix time to DateTime
            DateTimeOffset dateTimeOffset = DateTimeOffset.FromUnixTimeSeconds(unixTime);
            string time = dateTimeOffset.LocalDateTime.ToString("HH:mm:ss");

            return time;
        }
    }
    public class jsonData
    {
        public string serial { get; set; }
    }
    public class receiveData
    {
        public string data { get; set; }
    }
}